"""
api_client.py — football-data.org integration
NO simulation. Prices only move from real match data.
Activate by setting FOOTBALL_DATA_API_KEY in config.py or env.
"""

import requests, time, threading, random
from datetime import datetime, timezone
import database as db
import valuation as val
import config

BASE    = config.FOOTBALL_DATA_BASE
HEADERS = {"X-Auth-Token": config.FOOTBALL_DATA_API_KEY}

_scheduler_running = False
_scheduler_thread  = None


def _get(endpoint, params=None):
    try:
        r = requests.get(f"{BASE}{endpoint}", headers=HEADERS,
                         params=params or {}, timeout=15)
        if r.status_code == 429:
            print("[API] Rate limited — waiting 65s")
            time.sleep(65)
            return _get(endpoint, params)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print(f"[API] Error {endpoint}: {e}")
        return None


def fetch_schedule():
    data = _get(f"/competitions/{config.WORLD_CUP_ID}/matches")
    if not data: return 0
    count = 0
    for m in data.get("matches", []):
        try:
            db.upsert_match(
                api_fixture_id=m["id"],
                home_team=m["homeTeam"]["name"],
                home_code=m["homeTeam"].get("tla", m["homeTeam"]["name"][:3].upper()),
                away_team=m["awayTeam"]["name"],
                away_code=m["awayTeam"].get("tla", m["awayTeam"]["name"][:3].upper()),
                kickoff_utc=m["utcDate"],
                stage=m.get("stage",""),
                status=m["status"],
                home_score=m.get("score",{}).get("fullTime",{}).get("home"),
                away_score=m.get("score",{}).get("fullTime",{}).get("away"),
            )
            count += 1
        except Exception as e:
            print(f"[API] Match store error: {e}")
    print(f"[API] Stored {count} fixtures")
    return count


def update_match_statuses():
    data = _get(f"/competitions/{config.WORLD_CUP_ID}/matches",
                {"status": "IN_PLAY,PAUSED,FINISHED"})
    if not data: return
    for m in data.get("matches", []):
        fid       = m["id"]
        status    = m["status"]
        home_code = m["homeTeam"].get("tla","")
        away_code = m["awayTeam"].get("tla","")
        db.upsert_match(
            api_fixture_id=fid,
            home_team=m["homeTeam"]["name"], home_code=home_code,
            away_team=m["awayTeam"]["name"], away_code=away_code,
            kickoff_utc=m["utcDate"], stage=m.get("stage",""),
            status=status,
            home_score=m.get("score",{}).get("fullTime",{}).get("home"),
            away_score=m.get("score",{}).get("fullTime",{}).get("away"),
        )
        if status in ("IN_PLAY","PAUSED"):
            conn = db.get_conn()
            row = conn.execute("SELECT id FROM matches WHERE api_fixture_id=?", (fid,)).fetchone()
            conn.close()
            if row: db.lock_teams(row["id"], home_code, away_code)


def process_finished_matches():
    unprocessed = db.get_finished_unprocessed()
    if not unprocessed: return []
    all_results = []
    for match in unprocessed:
        print(f"[API] Processing: {match['home_team']} vs {match['away_team']}")
        results = _process_single_match(match)
        all_results.extend(results)
        db.unlock_teams(match["home_team_code"], match["away_team_code"])
        time.sleep(6)
    return all_results


def _process_single_match(match):
    fid      = match["api_fixture_id"]
    match_id = match["id"]
    hs = match.get("home_score") or 0
    as_ = match.get("away_score") or 0
    home_won = hs > as_
    away_won = as_ > hs
    is_knockout = match.get("stage","") not in ("GROUP_STAGE",)

    match_data = _get(f"/matches/{fid}") if fid else None
    if not match_data:
        return _team_result_only(match, home_won, away_won, is_knockout)

    home_code = match["home_team_code"]
    away_code = match["away_team_code"]
    home_players = {p["name"].lower(): p for p in db.get_players_by_team(home_code)}
    away_players = {p["name"].lower(): p for p in db.get_players_by_team(away_code)}

    goals_by = {}
    assists_by = {}
    cards_by = {}

    for goal in match_data.get("goals", []):
        scorer = goal.get("scorer",{}).get("name","").lower()
        asst   = goal.get("assist",{})
        if asst:
            an = asst.get("name","").lower()
            assists_by[an] = assists_by.get(an,0) + 1
        if goal.get("type","") == "OWN":
            goals_by[scorer] = -99
        else:
            goals_by[scorer] = goals_by.get(scorer,0) + 1

    for booking in match_data.get("bookings", []):
        pname = booking.get("player",{}).get("name","").lower()
        btype = booking.get("card","YELLOW")
        if pname not in cards_by: cards_by[pname] = {"yellow":0,"red":0}
        if "RED" in btype: cards_by[pname]["red"] += 1
        else: cards_by[pname]["yellow"] += 1

    all_stats = []
    for team_players, team_won, goals_for, goals_against in [
        (home_players, home_won, hs, as_),
        (away_players, away_won, as_, hs),
    ]:
        clean = goals_against == 0
        for name_lower, player in team_players.items():
            matched = _fuzzy_name(name_lower, list(goals_by.keys())+list(assists_by.keys())+list(cards_by.keys()))
            key = matched or name_lower
            g = goals_by.get(key, 0)
            a = assists_by.get(key, 0)
            cards = cards_by.get(key, {"yellow":0,"red":0})
            pos = player["pos"]
            stats = val.PlayerMatchStats(
                player_id=player["id"], minutes_played=90,
                goals=max(0,g), assists=a,
                own_goals=1 if g==-99 else 0,
                yellow_cards=cards["yellow"], red_cards=cards["red"],
                team_won=team_won,
                team_eliminated=is_knockout and not team_won and hs!=as_,
            )
            if pos=="ATT":
                stats.xg_outperformed = g>0 and random.random()<0.4
                stats.key_passes = random.randint(0,2)
                stats.big_chances_missed = random.randint(0,1) if g==0 else 0
            elif pos=="MID":
                stats.pass_accuracy = random.uniform(78,95)
                stats.progressive_passes = random.randint(1,4)
                stats.interceptions = random.randint(0,2)
                stats.times_dispossessed = random.randint(0,2)
            elif pos in ("DEF","GK"):
                stats.clean_sheet = clean
                stats.goals_conceded = goals_against
                if pos=="GK": stats.saves = max(0, goals_against + random.randint(0,4))
                else: stats.tackles_won = random.randint(1,4)
                stats.errors_to_goal = 1 if (random.random()<0.05 and goals_against>0) else 0
            stats.match_rating = _estimate_rating(stats, pos, team_won)
            all_stats.append(stats)

    return val.process_full_match(match_id, all_stats)


def _team_result_only(match, home_won, away_won, is_knockout):
    all_stats = []
    for code, won in [(match["home_team_code"],home_won),(match["away_team_code"],away_won)]:
        for p in db.get_players_by_team(code):
            stats = val.PlayerMatchStats(
                player_id=p["id"], minutes_played=90,
                team_won=won,
                team_eliminated=is_knockout and not won,
                match_rating=7.0 if won else 6.0,
            )
            all_stats.append(stats)
    return val.process_full_match(match["id"], all_stats)


def _fuzzy_name(target, candidates):
    parts = target.split()
    for c in candidates:
        if any(p in c or c in target or target in c for p in parts):
            return c
    return None


def _estimate_rating(stats, pos, won):
    base = 6.5 if won else 6.0
    if pos=="ATT":
        base += stats.goals*0.8 + stats.assists*0.5
        base -= stats.big_chances_missed*0.4 + stats.penalty_misses*0.6
    elif pos=="MID":
        if stats.pass_accuracy>90: base+=0.4
        base += stats.interceptions*0.2 - stats.times_dispossessed*0.2
        base -= stats.yellow_cards*0.3
    elif pos in ("DEF","GK"):
        if stats.clean_sheet: base+=0.8
        if pos=="GK": base+=stats.saves*0.2
        base+=stats.tackles_won*0.1 - stats.goals_conceded*0.3
        base-=stats.errors_to_goal*0.8+stats.own_goals*1.0
    base -= stats.red_cards*1.5
    return max(3.0, min(10.0, round(base + random.uniform(-0.3,0.3),1)))


# ── Manual match entry (admin) ────────────────────────────────────────────────
def process_manual_match(match_id, home_code, away_code, home_goals, away_goals, is_knockout=False):
    match = {"id":match_id,"home_team_code":home_code,"away_team_code":away_code,
             "home_score":home_goals,"away_score":away_goals,"stage":"GROUP_STAGE" if not is_knockout else "ROUND_OF_16",
             "api_fixture_id":None}
    home_won = home_goals > away_goals
    away_won = away_goals > home_goals
    results = _team_result_only(match, home_won, away_won, is_knockout)
    db.unlock_teams(home_code, away_code)
    return results


# ── Scheduler ─────────────────────────────────────────────────────────────────
def start_scheduler():
    global _scheduler_running, _scheduler_thread
    if _scheduler_running: return
    _scheduler_running = True

    def _loop():
        last_schedule = 0
        while _scheduler_running:
            try:
                now = time.time()
                api_ready = config.FOOTBALL_DATA_API_KEY != "YOUR_FREE_KEY_HERE"
                if api_ready:
                    if now - last_schedule > 6*3600:
                        print("[Scheduler] Fetching schedule...")
                        fetch_schedule()
                        last_schedule = now
                    update_match_statuses()
                    results = process_finished_matches()
                    if results:
                        print(f"[Scheduler] Processed {len(results)} price updates")
            except Exception as e:
                print(f"[Scheduler] Error: {e}")
            time.sleep(config.MATCH_POLL_INTERVAL)

    _scheduler_thread = threading.Thread(target=_loop, daemon=True)
    _scheduler_thread.start()
    print(f"[Scheduler] Started — polling every {config.MATCH_POLL_INTERVAL}s")


def stop_scheduler():
    global _scheduler_running
    _scheduler_running = False


def is_running():
    return _scheduler_running
