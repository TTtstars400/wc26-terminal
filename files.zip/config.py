"""
config.py — Central configuration for WC26 Equity Terminal
"""
import os

# ── API ───────────────────────────────────────────────────────────────────────
# FREE key: https://www.football-data.org/client/register  (no card needed)
FOOTBALL_DATA_API_KEY = os.environ.get("FOOTBALL_DATA_API_KEY", "YOUR_FREE_KEY_HERE")
FOOTBALL_DATA_BASE    = "https://api.football-data.org/v4"
WORLD_CUP_ID          = int(os.environ.get("WORLD_CUP_ID", "2000"))

# Poll every 5 minutes for finished matches — well within free tier
MATCH_POLL_INTERVAL   = int(os.environ.get("MATCH_POLL_INTERVAL", "300"))

# ── App ───────────────────────────────────────────────────────────────────────
APP_TITLE       = "WC26 Equity Terminal"
STARTING_CASH   = 700_000_000.0   # $700 million per user
MIN_SHARES      = 0.01

# Tournament start — no price movement before this date
TOURNAMENT_START = "2026-06-11"

# ── Match rating → price delta ────────────────────────────────────────────────
RATING_THRESHOLDS = [
    (8.5, +4.0),   # Outstanding
    (7.5, +2.0),   # Good
    (6.5,  0.0),   # Average
    (5.0, -1.0),   # Below par
    (0.0, -3.0),   # Poor
]

# ── Design ────────────────────────────────────────────────────────────────────
# WC 2026 official palette
COLOR_BG         = "#0B0E1A"
COLOR_BG2        = "#0E122A"
COLOR_BG3        = "#141830"
COLOR_RED        = "#E61D25"
COLOR_GOLD       = "#C9A84C"
COLOR_GREEN      = "#2ECC71"
COLOR_BORDER     = "#1C2340"
COLOR_TEXT_DIM   = "#5A6080"
COLOR_TEXT_MED   = "#8090B0"
COLOR_TEXT_LIGHT = "#C8D0E0"
